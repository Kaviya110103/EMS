package com.employeesystem.emsbackend.config;

public class WebSecurityConfigurerAdapter {

}
