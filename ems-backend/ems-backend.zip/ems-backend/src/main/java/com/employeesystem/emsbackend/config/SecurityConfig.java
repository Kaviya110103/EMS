package com.employeesystem.emsbackend.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
public class SecurityConfig {

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http.csrf(csrf -> csrf.disable()) // Disable CSRF for testing purposes
            .authorizeHttpRequests(auth -> auth
                // Allow unauthenticated access to specific endpoints
                .requestMatchers(
                    "/api/users/save",          // User registration
                    "/api/users/authenticate",  // User authentication
                    "/api/emp/authenticate",    // Employee authentication
                    "/api/emp",                 // Create employee
                    "/api/leave-permissions/**",// Allow access to leave-permissions endpoints
                    "/api/images/**",           // Allow access to image endpoints
                    "/uploads/**"  ,
                    "/api/emp/**"    ,
                    "/api/employees" ,
                    "/api/attendance"  ,
                    "/api/attendance/**"           // Allow access to static uploaded files
                ).permitAll()
                .requestMatchers("/api/emp/{id}").authenticated() // Protect /api/emp/{id} for authenticated users
                // Secure all other endpoints
                .anyRequest().authenticated()
            )
            .formLogin(form -> form.disable()); // Disable default form login (for JWT or other custom auth methods)

        return http.build();
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();  // Password encoder for secure password hashing
    }
}
