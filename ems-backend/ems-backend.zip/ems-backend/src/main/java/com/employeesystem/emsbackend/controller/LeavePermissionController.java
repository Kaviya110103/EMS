package com.employeesystem.emsbackend.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.employeesystem.emsbackend.entity.Attendance;
import com.employeesystem.emsbackend.entity.LeavePermission;
import com.employeesystem.emsbackend.repository.AttendanceRepository;
import com.employeesystem.emsbackend.repository.EmployeeRepository;
import com.employeesystem.emsbackend.repository.LeavePermissionRepository;
import com.employeesystem.emsbackend.service.AttendanceService;

import java.util.List;

@RestController
@CrossOrigin(origins = "http://localhost:3000")

@RequestMapping("/api/leave-permissions")
public class LeavePermissionController {

    @Autowired
    private LeavePermissionRepository repository;
    @Autowired
    private AttendanceService attendanceService;

    @Autowired
    private AttendanceRepository attendanceRepository;

    @Autowired
    private LeavePermissionRepository leavePermissionRepository;
    @Autowired
    private EmployeeRepository employeeRepository;

   


    // Create a new leave or permission request
    @PostMapping("/{attendanceId}")
    public ResponseEntity<?> createLeavePermission(
            @PathVariable Long attendanceId,
            @RequestBody LeavePermission leavePermission) {
        try {
            Attendance attendance = attendanceRepository.findById(attendanceId)
                    .orElseThrow(() -> new RuntimeException("Attendance not found with id: " + attendanceId));

            leavePermission.setAttendance(attendance);

            LeavePermission savedLeavePermission = leavePermissionRepository.save(leavePermission);

            return ResponseEntity.status(HttpStatus.CREATED).body(savedLeavePermission);
        } catch (RuntimeException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
        }
    }
    
    @GetMapping("/attendance/{attendanceId}")
    public List<LeavePermission> getLeavePermissionsByAttendanceId(@PathVariable Long attendanceId) {
        return leavePermissionRepository.findByAttendanceId(attendanceId);
    }

    


    // Get all leave/permission requests
    @GetMapping
    public List<LeavePermission> getAllLeavePermissions() {
        return repository.findAll();
    }

    // Get leave/permission requests by employeeId
    @GetMapping("/employee/{employeeId}")
    public List<LeavePermission> getLeavePermissionsByEmployeeId(@PathVariable String employeeId) {
        return repository.findByEmployeeId(employeeId);
    }

    // Get a specific leave/permission request by ID
    @GetMapping("/{id}")
    public LeavePermission getLeavePermissionById(@PathVariable Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new RuntimeException("Request not found with id: " + id));
    }

    // Update the status of a request
    @CrossOrigin(origins = "http://localhost:3000")
    @PutMapping("/{id}/status")
    public LeavePermission updateStatus(@PathVariable Long id, @RequestParam String status) {
        // Find the LeavePermission by ID
        LeavePermission leavePermission = repository.findById(id)
                .orElseThrow(() -> new RuntimeException("LeavePermission not found with ID: " + id));
        
        // Update the status
        leavePermission.setStatus(status);

        // Save the updated entity back to the database
        return repository.save(leavePermission);
    }
    

    // Delete a request
    @DeleteMapping("/{id}")
    public String deleteLeavePermission(@PathVariable Long id) {
        repository.deleteById(id);
        return "Request deleted with id: " + id;
    }
     // Get leave/permission request by both employeeId and attendanceId
     @GetMapping("/employee/{employeeId}/attendance/{attendanceId}")
     public List<LeavePermission> getLeavePermissionsByEmployeeIdAndAttendanceId(
             @PathVariable Long employeeId,
             @PathVariable Long attendanceId) {
         return leavePermissionRepository.findByAttendance_Employee_IdAndAttendance_Id(employeeId, attendanceId);
     }
}
