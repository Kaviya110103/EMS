package com.employeesystem.emsbackend.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.employeesystem.emsbackend.entity.LeavePermission;

public interface LeavePermissionRepository extends JpaRepository<LeavePermission, Long> {
    List<LeavePermission> findByEmployeeId(String employeeId);

    List<LeavePermission> findByAttendanceId(Long attendanceId);
    List<LeavePermission> findByAttendance_Employee_IdAndAttendance_Id(Long employeeId, Long attendanceId);
}