package com.employeesystem.emsbackend.controller;

public class AttendanceRequest {

    public Long getEmployeeId() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'getEmployeeId'");
    }

}
