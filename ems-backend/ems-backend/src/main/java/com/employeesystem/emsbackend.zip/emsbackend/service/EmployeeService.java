package com.employeesystem.emsbackend.service;

import com.employeesystem.emsbackend.entity.Employee;
import com.employeesystem.emsbackend.exception.ResourceNotFoundException;
import com.employeesystem.emsbackend.repository.EmployeeRepository;

import jakarta.persistence.criteria.Path;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.http.ResponseEntity;

@Service
@AllArgsConstructor
public class EmployeeService {
    private final EmployeeRepository employeeRepository;

    public Employee addEmployee(Employee employee) {
        return employeeRepository.save(employee);
    }

    public Employee findEmployeeById(Long employeeId) {
        return employeeRepository.findById(employeeId)
                .orElseThrow(() -> new ResourceNotFoundException("Employee Id " + employeeId + " not found"));
    }

    public List<Employee> getAllEmployee() {
        return employeeRepository.findAll();
    }

    public Employee updateEmployee(Long id, Employee updatedEmployee) {
        Employee emp = findEmployeeById(id);
        emp.setFirstName(updatedEmployee.getFirstName());
        emp.setLastName(updatedEmployee.getLastName());
        emp.setMobile(updatedEmployee.getMobile());
        emp.setGender(updatedEmployee.getGender());
        emp.setPosition(updatedEmployee.getPosition());
        emp.setBranch(updatedEmployee.getBranch());
        emp.setDob(updatedEmployee.getDob());
        emp.setEmail(updatedEmployee.getEmail());
        emp.setUsername(updatedEmployee.getUsername());
        emp.setPassword(updatedEmployee.getPassword());
        return employeeRepository.save(emp);
    }

    public void deleteEmployeeById(Long id) {
        boolean exist = employeeRepository.existsById(id);
        if (!exist) {
            throw new ResourceNotFoundException("Employee not found Id " + id);
        }
        employeeRepository.deleteById(id);
    }

    // New methods to find by First Name and Email, and Username
    public Employee findEmployeeByFirstNameAndEmail(String firstName, String email) {
        return employeeRepository.findByFirstNameAndEmail(firstName, email);
    }

    public Employee findEmployeeByUsername(String username) {
        return employeeRepository.findByUsername(username);
    }

    // Optionally, you can implement this method or remove it
    public List<Employee> getAllEmployees() {
        // If you want this method to return all employees, it could just call getAllEmployee:
        return getAllEmployee();
    }

     private final String uploadDir = "uploads/profileImages/"; // Directory to save images

    public Employee uploadProfileImage(Long employeeId, MultipartFile file) throws IOException {
        Employee employee = findEmployeeById(employeeId);

        // Ensure the upload directory exists
        java.nio.file.Path path = Paths.get(uploadDir);
        if (!Files.exists(path)) {
            Files.createDirectories(path);
        }

        // Save the file to the upload directory
        String fileName = employeeId + "_" + file.getOriginalFilename();
        java.nio.file.Path filePath = path.resolve(fileName);
        Files.write(filePath, file.getBytes());

        // Update the employee's profile image field
        employee.setProfileImage(filePath.toString()); // Save the image path in the database
        return employeeRepository.save(employee);
    }
}
