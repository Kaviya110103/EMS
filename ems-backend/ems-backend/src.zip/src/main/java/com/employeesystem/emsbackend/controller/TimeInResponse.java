package com.employeesystem.emsbackend.controller;

import java.time.LocalDate;
import java.time.LocalTime;

public class TimeInResponse {

    public TimeInResponse(LocalDate dateIn, LocalTime timeIn) {
        //TODO Auto-generated constructor stub
    }

}
